(function(){
	window.my_tmpl={
		//创建item模板
		itemTmpl:function(obj){
			var tmpl='<li class="mui-table-view-cell">'
			
					+'<div class="tuijian-l">'+obj.sourceName+'</div>'
				+'<div class="tuijian-r">'+obj.sourceType+'</div>'
				+'</div>'
			+'</li>';
			return tmpl;
		},
		
		userInfo:function(obj){
			var tmpl='<li class="mui-table-view-cell">'
					+'<div class="tuijian-l">'+obj.userName+'</div>'
				+'<div class="tuijian-r">'+obj.userCount+'</div>'
				+'</div>'
			+'</li>';
			return tmpl;
		},
		editState:function(obj){
			var tmpl='<li class="mui-table-view-cell">'
					+'<div class="tuijian-l">'+obj.userCount+'</div>'
				+'<div class="tuijian-r">'+obj.isProhibit+'</div>'
				+'</div>'
			+'</li>';
			return tmpl;
		},
		
	}
	
	
	
})();